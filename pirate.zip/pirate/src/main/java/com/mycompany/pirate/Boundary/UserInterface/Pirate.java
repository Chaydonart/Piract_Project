/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pirate.Boundary.UserInterface;

/**
 *
 * @author BEN JAAFAR
 */
public class Pirate {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
