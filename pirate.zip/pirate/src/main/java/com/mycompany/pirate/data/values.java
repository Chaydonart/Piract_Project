/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pirate.data;

import java.awt.Color;

/**
 *
 * @author BEN JAAFAR
 */
public class values {
     public static final Color GREEN_COLOR_BACKGROUND = new Color(34, 111, 55);
     public static final Color RED_CUSTOM = new Color(170,39,23);
     public static final Color GREEN_CUSTOM = new Color(0,105,91);
     public static final Color BLACK_CUSTOM = new Color(74,32,41);
     
     public static final Color INFO_PANEL_COLOR_BACKGROUND = new Color(24, 101, 45);
     public static final Color TRANSPARENT_COLOR_BACKGROUND = new Color(255, 0, 0, 0);
}
