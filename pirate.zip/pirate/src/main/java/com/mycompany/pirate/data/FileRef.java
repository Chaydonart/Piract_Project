/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pirate.data;

/**
 *
 * @author BEN JAAFAR
 */
public class FileRef {
    public static final String IMAGE_LIFE_PLAYER_1 = "src\\main\\java\\res\\LifeRessourcePlayer1.png";
    public static final String IMAGE_LIFE_PLAYER_2= "src\\main\\java\\res\\LifeRessourcePlayer2.png";
    public static final String IMAGE_SLOT_MACHINE = "src\\main\\java\\res\\slotMachine.png";
    public static final String BACKGROUND_IMAGE = "src\\main\\java\\res\\plateau.png";
}
