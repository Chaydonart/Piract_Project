package pirate;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDeplacerPion {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
